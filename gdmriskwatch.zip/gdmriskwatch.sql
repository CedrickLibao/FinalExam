-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 10, 2023 at 08:06 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gdmriskwatch`
--

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `age` int(11) NOT NULL,
  `birthday` date NOT NULL,
  `address` varchar(250) NOT NULL,
  `contact` varchar(250) NOT NULL,
  `lmp` varchar(250) NOT NULL,
  `ldc` varchar(250) NOT NULL,
  `aog` varchar(250) NOT NULL,
  `gp` varchar(250) NOT NULL,
  `factor1` text NOT NULL,
  `factor2` text NOT NULL,
  `factor3` text NOT NULL,
  `factor4` text NOT NULL,
  `factor5` text NOT NULL,
  `factor6` text NOT NULL,
  `factor7` text NOT NULL,
  `factor8` text NOT NULL,
  `factor9` text NOT NULL,
  `factor10` text NOT NULL,
  `risk` text NOT NULL,
  `assessedBy` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`id`, `name`, `age`, `birthday`, `address`, `contact`, `lmp`, `ldc`, `aog`, `gp`, `factor1`, `factor2`, `factor3`, `factor4`, `factor5`, `factor6`, `factor7`, `factor8`, `factor9`, `factor10`, `risk`, `assessedBy`) VALUES
(3, 'John Yrrah Cabiles', 12, '0000-00-00', 'BLK 635 L13 ROAD 639 PHASE 6C METROGATE SILANG ESTATES, BRGY. ADLAS', '09569549490', 'dsada', 'dsadsa', 'dsadsa', 'dsada', 'YES', 'YES', 'YES', 'YES', 'YES', 'YES', 'YES', 'YES', 'YES', 'YES', 'HIGH', 'saSA1231'),
(4, 'John Yrrah Cabiles', 12, '2002-06-22', 'BLK 635 L13 ROAD 639 PHASE 6C METROGATE SILANG ESTATES, BRGY. ADLAS', '09569549490', 'dsada', 'dsadsa', 'dsadsa', 'dsada', 'NO', 'YES', 'NO', 'NO', 'NO', 'NO', 'NO', 'YES', 'NO', 'NO', 'LOW', 'saSA1231');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'admin', 'password');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `patients`
--
ALTER TABLE `patients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
